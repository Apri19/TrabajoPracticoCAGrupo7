 poweroff
 poweroff
hostnamectl
hostnamectl set-hostname TPServer
hostnamectl
exit
ping -c 3 8.8.8.8
apt update
apt nano
apt install nano
clear
echo "nameserver 8.8.8.8" > /etc/resolv.conf
echo "nameserver 1.1.1.1" >> /etc/resolv.conf
cat /etc/resolv.conf
apt install nano
apt update
apt install nano
clear
echo "deb http://deb.debian.org/debian bullseye main contrib non-free" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bullseye-updates main contrib non-free" >> /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bullseye-security main contrib non-free" >> /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
apt install nano
clear
nano /etc/interfaces
clear
cd /etc
ls
clear
ls -n
clear
ls -s
clear
cd /etc/interfaces
find interfaces
cd /interfaces
ls -l inter*
cd..
cd /root
clear
apt install -y openssh-server
apt-get update
apt install -y openssh-server
apt install ssh
clear
echo "deb http://deb.debian.org/debian bullseye main contrib non-free" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bullseye-updates main contrib non-free" >> /etc/apt/sources.list
rm -rf /var/lib/apt/lists/*
apt clean
apt update
apt install ssh
clear
nano /etc/ssh/sshd_config
clear
nano /etc/ssh/sshd_config
clear
ls -a
ls -la /root
ls -la /root
mkdir -p /root/.ssh
ls -la /root
chmod 700 /root/.ssh
ls -la /root
nano /.ssh/authorized_keys
nano /root/.ssh/authorized_keys
clear
ls -l
ls
cd /.ssh
/root
cd /root
ls
ls -a
cd /root/.ssh
ls
cd..
cd ..
/.ssh
authorized_keys
clear
pwd
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
systemctl restart ssh
ip a
nano /etc/network/interfaces
clear
poweroff
nano /etc/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
exit
chmod 600 /root/.ssh/authorized_keys
ls -la
cd /root/.ssh
ls -l
systemclt restart ssh
cd ..
systemclt restart ssh
systemctl restart ssh
exit
apt install -y mariadb-server php-mysql
system restart apache2
systemctl restart apache2
systemctl status mariadb
clear
mariadb-secure-installation
nano /root/.ssh/authorized_keys
nano /root/.ssh/authorized_keys
fg
nano /root/.ssh/authorized_keys
clear
ls -l
man mariadb
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
chown -R www-data:www-data /var/www/html/
chmod 644 /var/www/html/index.php /var/www/html/logo.png
ls
ls -l
cd /var
ls -la
cd /www
cd www
ls -l
cd html
ls -l
clear
cd /root
head -n 25 /var/www/html/index.php
mariadb < /root/db.sql
ls -l
cd /mariadb
cd mariadb
cd /var/www/html
ls -l
cd ..
cd /root
clear
rm /var/www/html/info.php
rm /var/www/html/index.html
exit
systemctl restart networking
ip a
nano /etc/network/interfaces
clear
ip a
ip link set enp0s3 up
dhclient enp0s3
ip a
cat /root/.ssh/authorized_keys
clear
nano /etc/ssh/sshd_config
systemctl restart networking
clear
nano /etc/network/interfaces
clear
nano /etc/network/interfaces
clear
apt update
apt install -y apache2 php libapache2-mod-php
systemctl status apache2
clear
echo "<?php phpinfo(); ?>" > /var/www/html/info.php
poweroff
lsblk
poweroff
