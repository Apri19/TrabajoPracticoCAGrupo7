mostrar_ayuda() {
    echo "Uso: $0 [ORIGEN] [DESTINO]"
    echo ""
    echo "Descripcion:"
    echo "  Realiza un backup comprimido (.tar.gz) de un directorio origen"
    echo "  hacia un directorio destino, con formato de fecha ANSI (YYYYMMDD)."
    echo ""
    echo "Opciones:"
    echo "  -help       Muestra este menu de ayuda y finaliza la ejecucion."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  $0 /www_dir /backup_dir"
}

if [ "$1" == "-help" ] || [ "$1" == "--help" ]; then
    mostrar_ayuda
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: Cantidad de argumentos incorrecta."
    echo "Ejecute '$0 -help' para ver instrucciones de uso."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no esta accesible."
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no esta accesible."
    exit 3
fi

if [ ! -w "$DESTINO" ]; then
    echo "Error: No hay permisos de escritura en el destino '$DESTINO'."
    exit 4
fi

FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")

ARCHIVO_SALIDA="${DESTINO}/${NOMBRE_BASE}bkp${FECHA}.tar.gz"

echo "Iniciando backup de '$ORIGEN' en '$ARCHIVO_SALIDA'..."

tar -cvzf "$ARCHIVO_SALIDA" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE" 2>/dev/null

if [ $? -eq 0 ]; then
    echo "Backup completado exitosamente: $ARCHIVO_SALIDA"
    exit 0
else
    echo "Error: Ocurrio un problema al generar el archivo comprimido."
    exit 5
fi
